<?php

ob_start();

include_once "sessionCheck.php";

include_once "class/connect.php";



include_once "includes/library-functions.php";



$objConnect = new connect();



if ($objConnect->checkConnection())



{



	$action = mysql_real_escape_string($_REQUEST['action']);



	switch ($action)



	{

		

		//coupan 

			case 'addCoupan':



		$coupan = new coupan();



		$coupan->addCoupan($_POST['info']);

		header('location:coupan-list.php');

		break;







	case 'editCoupan':

		$coupan = new coupan();

		$coupan->editCoupan($_POST['info'],$_POST['coupanId']);

		header('location:' . $_POST['returnUrl']);

		break;







	case 'deleteCoupan':



		$coupan = new coupan();



		$coupan->deleteCoupan($_POST['coupanId']);

		header('location:' . $_POST['returnUrl']);

		break;







	case 'activateCoupan':



		$coupan = new coupan();



		$coupan->activateCoupan($_POST['coupanId']);



		header('location:' . $_POST['returnUrl']);



		break;

		

		case 'deActivateCoupan':



		$coupan = new coupan();



		$coupan->deActivateCoupan($_POST['coupanId']);

		header('location:' . $_POST['returnUrl']);



		break;

		//end

		



	case 'change-password':

		$login = new login();

		$login->changePassword($_POST,$_POST['user_id']);

		header('location:'.$_POST['returnUrl']);

		break;

		

        

        case'UserLogin':

		$login = new login();

		$login->adminLogin($_POST);

		header('location:'.$_POST['returnUrl']);

		break;

				

		



	case 'addCategory':



		$objCategory = new category();



		$objCategory->addCategory($_POST['info'],$_FILES['img']);



		header('location:show-food-category.php');



		break;







	case 'editCategory':



		$objCategory = new category();

		$objCategory->editCategory($_POST['info'], $_FILES['img'], $_POST['categoryId'],$_POST['oldFile']);

		header('location:' . $_POST['returnUrl']);

		break;







	case 'deleteCategory':



		$objCategory = new category();



		$objCategory->deleteCategory($_POST['category_id']);



		header('location:' . $_POST['returnUrl']);



		break;







	case 'activateCategory':



		$objCategory = new category();



		$objCategory->activateCategory($_POST['category_id']);



		header('location:' . $_POST['returnUrl']);



		break;

		

		case 'deActivateCategory':



		$objCategory = new category();



		$objCategory->deActivateCategory($_POST['category_id']);



		header('location:' . $_POST['returnUrl']);



		break;







	



	case 'addBrand':



		$objBrand = new brand();



		$objBrand->addBrand($_POST['info']);



		header('location:show-brand.php');



		break;







	case 'editBrand':



		$objBrand = new brand();



		$objBrand->editBrand($_POST['info'], 'id=' . $_POST['brandId']);



		header('location:show-brand.php');



		break;







	case 'deleteBrand':



		$objBrand = new brand();



		$objBrand->deleteBrand($_POST['brandId']);



		header('location:show-brand.php');



		break;







	case 'activateBrand':



		$objBrand = new brand();



		$objBrand->activateBrand($_POST['brandId']);



		header('location:show-brand.php');



		break;







	case 'deActivateBrand':



		$objBrand = new brand();



		$objBrand->deActivateBrand($_POST['brandId']);



		header('location:show-brand.php');



		break;







		//for search







	case 'addSearch':



		$objSearch = new search();



		$objSearch->addSearch($_POST['info']);



		header('location:'.$_POST['returnUrl']);



		break;



	



	case 'editSearch':



		$objSearch = new search();



		$objSearch->editSearch($_POST['info'], 'id=' . $_POST['moduleId']);



		header('location:show-search-module.php');



		break;







	case 'deleteSearch':



		$objSearch = new search();



		$objSearch->deleteSearch($_POST['searchId']);



		header('location:show-search-module.php');



		break;







	case 'activateSearch':



		$objSearch = new search();



		$objSearch->activateSearch($_POST['searchId']);



		header('location:show-search-module.php');



		break;







	case 'deActivateSearch':



		$objSearch = new search();



		$objSearch->deActivateSearch($_POST['searchId']);



		header('location:show-search-module.php');



		break;











		//for filters



		



	case 'addFilter':



		$objSearch = new search();



		$objSearch->addFilter($_POST['info']);



		header('location:'.$_POST['returnUrl']);



		break;



			



	case 'mapFilter':



		$objSearch = new search();



		$objSearch->mapFilter($_POST['info'],$_POST['filter_opt']);

		header('location:'.$_POST['returnUrl']);



		break;



			



			



	case 'editFilter':



		$objSearch = new search();



		$objSearch->editFilter($_POST['info'], 'id=' . $_POST['filterId']);



		header('location:'.$_POST['returnUrl']);



		break;







	case 'deleteFilters':



		$objSearch = new search();



		$objSearch->deleteFilters($_POST['filterId']);



		header('location:'.$_POST['returnUrl']);



		break;







	case 'activateFilters':



		$objSearch = new search();



		$objSearch->activateFilters($_POST['filterId']);



		header('location:'.$_POST['returnUrl']);



		break;







	case 'deActivateFilters':



		$objSearch = new search();



		$objSearch->deActivateFilters($_POST['filterId']);



		header('location:'.$_POST['returnUrl']);



		break;



		



	case 'getBrand':



		$objBrand = new brand();



		$objBrand->displayListingBrand();



	 	break;



		



	case 'getCountry':



		echo "";



	 	break;



		//







	case 'addProduct':



		$objProduct = new product();

		$objProduct->addProduct($_POST['info'],$_FILES['img'],$_POST['addon']);

		break;







	case 'updateProduct':



		$objProduct = new product();



		$objProduct->updateProduct($_POST['info'],$_FILES['img'],$_POST['productId'],$_POST['oldFile'],$_POST['addon']);



		header('location:show-food-item.php');



		break;







	case 'deleteProducts':



		$objProduct = new product();



		$objProduct->deleteProducts($_POST['productId']);



		header('location:'.$_POST['returnUrl']);



		break;







	case 'activateProducts':



		$objProduct = new product();

		$objProduct->activateProducts($_POST['productId']);

		header('location:'.$_POST['returnUrl']);



		break;

		



	case 'deActivateProducts':



		$objProduct = new product();



		$objProduct->deActivateProducts($_POST['productId']);

		header('location:'.$_POST['returnUrl']);

		break;







	case 'setFront':



		$objProduct = new product();



		$objProduct->setFront($_POST);



		break;







	case 'setBack':



		$objProduct = new product();



		$objProduct->setBack($_POST);



		break;







	case 'delBannerImage':



		$objSlider = new slider();



		$objSlider->delSliderImage($_POST['id']);



		break;







	case 'setActive':



		$objSlider = new slider();



		$objSlider->setActive($_POST);



		break;







		// news section starts







	case 'addNews':



		$objNews = new news();



		$objNews->addNews($_POST['info']);



		header('location:show-news.php');



		break;







	case 'editNews':



		$objNews = new news();



		$objNews->editNews($_POST['info'], 'id=' . $_POST['newsid']);



		header('location:show-news.php');



		break;







	case 'deleteNews':



		$objNews = new news();



		$objNews->deleteNews($_POST['newsId']);



		header('location:show-news.php');



		break;







	case 'activateNews':



		$objNews = new news();



		$objNews->activateNews($_POST['newsId']);



		header('location:show-news.php');



		break;







	case 'deActivateNews':



		$objNews = new news();



		$objNews->deActivateNews($_POST['newsId']);



		header('location:show-news.php');



		break;







		// news section ends







	case 'addUpcomingCars':



		$objNews = new upcomingcars();



		$fileName = uploadFileToDestination($_FILES['car_image']);



		$objNews->addUpcomingCars($_POST['info'], $fileName);



		header('location:show-upcoming-cars.php');



		break;







	case 'editCar':



		$objNews = new upcomingcars();



		$fileName = uploadFileToDestination($_FILES['car_image']);



		$objNews->editCar($_POST['info'], 'id=' . $_POST['carid'], $fileName);



		header('location:show-upcoming-cars.php');



		break;







	case 'deleteCar':



		$objNews = new upcomingcars();



		$objNews->deleteCar($_POST['carid']);



		header('location:show-upcoming-cars.php');



		break;







	case 'setCarStatus':



		$objNews = new upcomingcars();



		$objNews->setCarStatus($_POST);



		header('location:show-upcoming-cars.php');



		break;







	case 'addSellProduct':



		$objProduct = new product();



		$objProduct->addProduct($_POST['info']);



		break;







	case 'editSellProduct':



		$objProduct = new sell();



		$objProduct->editProduct($_POST['info'], 'id=' . $_POST['productid']);



		header('location:show-sell-products.php');



		break;







	case 'deleteSellProducts':



		$objProduct = new sell();



		$objProduct->deleteSellProducts($_POST['productId']);



		header('location:show-sell-products.php');



		break;







	case 'activateSellProducts':



		$objProduct = new sell();



		$objProduct->activateSellProducts($_POST['productId']);



		header('location:show-sell-products.php');



		break;







	case 'deActivateSellProducts':



		$objProduct = new sell();



		$objProduct->deActivateSellProducts($_POST['productId']);



		header('location:show-sell-products.php');



		break;







	case 'delSellProdImage':



		$objImage = new image();



		$objImage->delSellProdImage($_POST['id']);



		break;







	case 'setSellFront':



		$objProduct = new product();



		$objProduct->setSellFront($_POST);



		break;







	case 'setSellBack':



		$objProduct = new product();



		$objProduct->setSellBack($_POST);



		break;







		// testimonial section start







	case 'addTestimonial':



		$objTestimonial = new testimonial();



		$objTestimonial->addTestimonial($_POST['info']);



		header('location:' . $_POST['returnUrl']);



		break;







	case 'deleteTestimonial':



		$objTestimonial = new testimonial();



		$objTestimonial->deleteTestimonial($_POST['testId']);



		header('location:' . $_POST['returnUrl']);



		break;







	case 'activateTestimonial':



		$objTestimonial = new testimonial();



		$objTestimonial->activateTestimonial($_POST['testId']);



		header('location:' . $_POST['returnUrl']);



		break;







	case 'deActivateTestimonial':



		$objTestimonial = new testimonial();



		$objTestimonial->deActivateTestimonial($_POST['testId']);



		header('location:' . $_POST['returnUrl']);



		break;







		// end testimonial section



		// advertisement section start







	case 'deleteAdvertisement':



		$objAdvertisement = new advertisement();



		$objAdvertisement->deleteAdvertisement($_POST['advertisementId']);



		header('location:' . $_POST['returnUrl']);



		break;







	case 'activateAdvertisement':



		$objAdvertisement = new advertisement();



		$objAdvertisement->activateAdvertisement($_POST['advertisementId']);



		header('location:' . $_POST['returnUrl']);



		break;







	case 'deActivateAdvertisement':



		$objAdvertisement = new advertisement();



		$objAdvertisement->deActivateAdvertisement($_POST['advertisementId']);



		header('location:' . $_POST['returnUrl']);



		break;



//attribute

	case 'addAttribute':

	$attr = new attribute();

	$attr->addAttribute($_POST);

	header('location:'.$_POST['returnUrl']);

	break;

	

	case 'updateAttribute':

	$attr = new attribute();

	$attr->updateAttribute($_POST);

	header('location:'.$_POST['returnUrl']);

	break;



	case 'activateAttr':

	$attr = new attribute();

	$attr->activateAttr($_POST['attr_id']);

	header('location:'.$_POST['returnUrl']);

	break;

	

	case 'deActivateAttr':

	$attr = new attribute();

	$attr->deActivateAttr($_POST['attr_id']);

	header('location:'.$_POST['returnUrl']);

	break;

	

	

	case 'deleteAttr':

	$attr = new attribute();

	$attr->deleteAttr($_POST['attr_id']);

	header('location:'.$_POST['returnUrl']);

	break;

	

	

//end

		// end advertisement section







	case 'getSubCategory':



		$objSubCate = new product();



		$subcategoryList = $objSubCate->getChildCategoryOnparentId(mysql_real_escape_string($_POST['parentId']));



		$strDisplay = "";



		foreach($subcategoryList as $subCategory)



		{



			if (empty($subCategory))



			{



				$strDisplay = $subCategory['id'] . '##' . $subCategory['brand_name'];



			}



			else



			{



				$strDisplay = $strDisplay . '####' . $subCategory['id'] . '##' . $subCategory['brand_name'];



			}



		}







		echo $strDisplay;



		break;



		



	 



		// for product reviews







	case 'addReview':



		$objReview = new review();



		$objReview->addReview($_POST['info']);



		header('location:show-reviews.php');



		break;







	case 'editReview':



		$objReview = new review();



		$objReview->editProduct($_POST['info'], 'id=' . $_POST['productid']);



		header('location:show-reviews.php');



		break;







	case 'deleteReview':



		$objReview = new review();



		$objReview->deleteReview($_POST['reviewId']);



		header('location:show-reviews.php');



		break;







	case 'activateReview':



		$objReview = new review();



		$objReview->activateReview($_POST['reviewId']);



		header('location:show-reviews.php');



		break;







	case 'deActivateReview':



		$objReview = new review();



		$objReview->deActivateReview($_POST['reviewId']);



		header('location:show-reviews.php');



		break;

	//sunil	

	

	case'activateDealer':

	$admin= new admin();

	$admin->ActivateDealer($_POST['dealerId']);

	header('location:show-all-dealer.php');	

	break;

	

	case'deActivateDealer':

	$admin= new admin();

	$admin->deActivateDealer($_POST['dealerId']);

	header('location:show-all-dealer.php');	

	break;

	

	

	case 'approval':

	$admin= new admin();

		if($admin->changeDealerStatus($_POST['dealerId'],$_POST['dealerSt'])){

		echo 1;	

		}

		else{

		echo 0;	

		}

	break;

	

	case'ApproveDealer':

	$admin =new admin();

	$admin->ApproveDealer($_POST['dealerId']);

	header('location:show-all-dealer.php');

	break;

	

	case 'UnpproveDealer':

	$admin =new admin();

	$admin->UnapproveDealer($_POST['dealerId']);

	header('location:show-all-dealer.php');

	break;

	

	case 'deleteDealer':

	$admin =new admin();

	$admin->DeleteAllDealer($_POST['dealerId']);

	header('location:show-all-dealer.php');

	break;

	//end

	case 'add_menu':

	$menu = new menu();

	$menu->addMenu($_POST);

	header('location:'.$_POST['returnUrl']);

	break;

	

	case 'deleteMenu':

	$menu = new menu();

	$menu->deleteMenu($_POST['menu_id'],$_POST['page_id']);

	header('location:'.$_POST['returnUrl']);	

	break;

	

	case 'updateMenu':

	$menu = new menu();

	$menu->UpdateMenu($_POST['parent'],$_POST['menu_id']);

	header('location:'.$_POST['returnUrl']);

	break;

	

	case 'menu_order_update':

	$menu= new menu();

	$menu->updateMenuOrder($_POST['order'],$_POST['menuId']);	

	break;

	

	case 'removeMenuLable':

	$menu = new menu();

	$menu->removeMenuLable($_POST['lbl_id'],$_POST['lbl']);

	break;

	

	

	

	case 'GetAttributeByModule':

	$menu = new search();

	$menu->GetAttributeByModule($_POST['module_id']);

	break;

	

	

	default:



	    $url=explode("?",$_POST['returnUrl']);



		flushTable(basename($url[0]));



		header("location:" . $_POST['returnUrl']);



	}



}



else



{



	echo "error in connection";



}







?>
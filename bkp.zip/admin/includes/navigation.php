<div id="nav">
		
	<div class="container">
		
		<a href="javascript:void(0)" class="btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
        	<i class="icon-reorder"></i>
      	</a>
		
		<div class="nav-collapse">
			
			<ul class="nav">
		
				<li class="nav-icon active">
					<a href="dashboard.html">
						<i class="icon-home"></i>
						<span>Home</span>
					</a>	    				
				</li>
				
				<li class="dropdown">					
					<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
						<i class="icon-th"></i>
						Manage Tracking
						<b class="caret"></b>
					</a>	
				
					<ul class="dropdown-menu">
						<li><a href="list-table.html">Add </a></li>
						<li><a href="list-table.html">Search</a></li>
                        <li><a href="#">Report</a></li>
						
					</ul>    				
				</li>
				
				
				
				
				
				
			
			</ul>
			
			
			
			
		</div> <!-- /.nav-collapse -->
		
	</div> <!-- /.container -->
	
</div>
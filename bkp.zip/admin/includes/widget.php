<div class="span4">
		  <div class="widget">					
					<div class="widget-header">
						<h3>
							<i class="icon-bookmark"></i> 
							Shortcuts								
						</h3>
						
						<div class="widget-actions">							
						</div> <!-- /.widget-actions -->						
					</div> <!-- /.widget-header -->
					
					<div class="widget-content">						
						<div class="shortcuts">
							<a href="add-user.php" class="shortcut">
								<i class="shortcut-icon icon-user"></i>
								<span class="shortcut-label">Add User</span>
							</a>
							
                            <a href="add-product.php" class="shortcut">
								<i class="shortcut-icon icon-th"></i>
								<span class="shortcut-label">Product</span>	
							</a>
                            
                            <a href="javascript:;" class="shortcut">
								<i class="shortcut-icon icon-signal"></i>
								<span class="shortcut-label">Reports</span>	
							</a> 
							</div> <!-- /.shortcuts -->
					</div> <!-- /.widget-content -->					
				</div><!-- /.widget --><!-- /.widget -->				
			</div>
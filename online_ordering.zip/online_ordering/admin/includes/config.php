<?php
date_default_timezone_set('America/New_York');
ini_set('display_errors','1');
define('WEBROOT','http://'.$_SERVER['SERVER_NAME'].'/online_ordering/');



define('WEBROOT_ADMIN','http://'.$_SERVER['SERVER_NAME'].'/online_ordering/admin/');



define('REPOSITORY',$_SERVER['DOCUMENT_ROOT'].'/online_ordering/repository/');



define('UPLOAD_REPOSITORY',$_SERVER['DOCUMENT_ROOT'].'/online_ordering/uploads/');



define('THUMB_REPOSITORY',$_SERVER['DOCUMENT_ROOT'].'/online_ordering/');



define('WEBROOT_REPOSITORY','http://'.$_SERVER['SERVER_NAME'].'/online_ordering/repository/');



define('WEBROOT_FRONT','http://'.$_SERVER['SERVER_NAME'].'/online_ordering/');



define('IMAGE_ROOT','http://'.$_SERVER['SERVER_NAME'].'/online_ordering/repository/');



define('SELL_IMAGE_ROOT','http://'.$_SERVER['SERVER_NAME'].'/online_ordering/uploads/');



define('PAGE_LIMIT','25');



?>

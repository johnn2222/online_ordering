<div class="col-lg-5 col-sm-5" >

          <div id="side-cont">

            <input type="hidden" id="mainStatus" value="" /> 
            <input type="hidden" id="nowltrStatus" value="" /> 
            <input type="hidden" id="customeTime" value="" /> 
            
		 <div id="headerMsg"></div>       

            <div class="border-panel hidden-xs">

            <div class="panel-body panel-header-right no-padding">

						<div class="discount-container clearfix">

							<div class="discount-left">

								<p class="discount-left-value">	15%</p><p>OFF</p>

							</div>

							<div class="discount-right">

				<span class="text-danger discount-right-title">15% Discount Minimum Order $50.00 (AUTOMATICALY APPLIED)</span>

								<p>Delivery Minimum: $15.00 </p>

							</div>

						</div>

					</div>

            </div>

            

            <!--chkout panel-->

            <div class="cont main-cart" id="fixed-cart">

            	<div class="tab-content">          	

             <div class="panel-table panel panel-default margin-top">    

                    <div class="panel-heading hidden-xs">

                        <div class="container-custom">		

                            <div class="row">

                                <div class="col-xs-3 checkout-quantity lang-qty">Qty</div>

                                <div class="col-xs-3 checkout-item lang-item">Item</div>

                                <div class="col-xs-2 checkout-price lang-price">Price</div>

								  <div class="col-xs-2 checkout-price lang-price">Total</div>

                                <div class="col-xs-1 checkout-edit">&nbsp;</div>

                                <div class="col-xs-1 checkout-close">&nbsp;</div>

                            </div>

                        </div>	

                    </div>

        

        		<div id="cart" class="panel-body js-cart cart-detail-body hidden-xs">

        
            <center><div class="loader2"></div></center>

                    <div class="container-custom order-item main-item">                                    
                        <div id="cartData"></div>
                        
                    </div>
                    <input type="hidden" id="addOnTotal" value="0">
                    <input type="hidden" id="coupApplied" value="0">                                       
                    <div id="addOnData"></div>
                        </div>
     
                 <div id="calcualtionPart"></div>    
                 
                 
                        

		
	</div>

			</div>

           
 </div>           

          
</div>
 </div>
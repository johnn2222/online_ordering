<?php 
ob_start();
session_start();
include_once("includes/config.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lovash Indian Restaurant </title>
<link rel='stylesheet' type='text/css'href='css/timepicki.css'/>

<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/magnific-popup.css"> 
<style>
.total-row{padding: 0 6px 4px 6px!important;}
</style>
</head>

<body>
<div class="fluid-container">

	<header>
        <div class="row">
            <div class="col-lg-12 col-sm-12">
                <nav>
                <div class="navbar-brand" style="padding:0px;">
                <a href="index.php"><img src="logo.png" alt="Lovash Indian Restaurant" width="150px"/> Lovash Indian Restaurant</a>
                </div>
                </nav>
            </div>
    
        </div>
   </header>